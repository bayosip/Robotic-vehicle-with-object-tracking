// Prototypes
void setup(void);
void initComm(void);
void i2c_tx(unsigned char address, unsigned char reg, unsigned char data);
void i2c_rx(unsigned char address, unsigned char regRead, unsigned char byteCount);
void SetTimer(unsigned int time);
void Wait4Timer(void);
void setup_md22(void);
void Forward (void);
void Reverse (void);
void Left (void);
void Right (void);


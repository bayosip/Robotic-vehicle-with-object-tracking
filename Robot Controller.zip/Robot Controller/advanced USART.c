#include <p18f4520.h>
#include <delays.h>
#include <string.h>
#include <usart.h>
#include "MD22.h"


// Configuration Bit Values
/** CONFIGURATION **************************************************/
        #pragma config OSC      = INTIO67
        #pragma config FCMEN    = OFF
        #pragma config IESO     = OFF
        #pragma config PWRT     = ON
        #pragma config BOREN    = OFF
        #pragma config WDT      = OFF
        #pragma config WDTPS    = 32768
        #pragma config MCLRE    = OFF
        #pragma config LPT1OSC  = OFF
        #pragma config PBADEN   = OFF
        #pragma config STVREN   = ON
        #pragma config LVP      = OFF
        #pragma config XINST    = OFF       			// Extended Instruction Set
        #pragma config CP0      = OFF
        #pragma config CP1      = OFF
        #pragma config CPB      = OFF
        #pragma config WRT0     = OFF
        #pragma config WRT1     = OFF
        #pragma config WRTB     = OFF       			// Boot Block Write Protection
        #pragma config WRTC     = OFF
        #pragma config EBTR0    = OFF
        #pragma config EBTR1    = OFF
        #pragma config EBTRB    = OFF

#define	MD22	0xB0	// Address of MD22

unsigned char s[21]; 			// used to print data to the LCD03

unsigned char command; 
unsigned int i =0, j=0,k=0,l=0, count;
unsigned int speed = 128;

void Forward (void){

	for ( i = 0; i<512; i++){	
	i2c_tx(MD22, 1, -speed);		// Drive motors with a speed of 100
	i2c_rx(MD22, 1, 2); 		// get values of speed and turn registers, place in buffer[0] and buffer[1]
	i2c_tx(MD22, 2, 128);		// Set turn register to value in x
	}
}

void Reverse (void){
for ( j = 0; j<512; j++){
	i2c_tx(MD22, 1, speed); 		// get values of speed and turn registers, place in buffer[0] and buffer[1]
	i2c_tx(MD22, 2, 128);		// Set turn register to value in x	
	}
}

void Left (void){
for ( k = 0; k<512; k++){
	i2c_tx(MD22, 1, 70);		// Drive motors with a speed of 100
	i2c_rx(MD22, 1, 2); 		// get values of speed and turn registers, place in buffer[0] and buffer[1]
	i2c_tx(MD22, 2, 86);		// Set turn register to value in x	
	}
}

void Right (void){
for ( l = 0; l<512; l++){
	i2c_tx(MD22, 1, 70);		// Drive motors with a speed of 100
	i2c_rx(MD22, 1, 2); 		// get values of speed and turn registers, place in buffer[0] and buffer[1]
	i2c_tx(MD22, 2, -86);		// Set turn register to value in x	
	}
}

void Stop(void){
	i2c_tx(MD22, 1, 128);		// Drive motors with a speed of 100
	i2c_rx(MD22, 1, 2); 		// get values of speed and turn registers, place in buffer[0] and buffer[1]
	i2c_tx(MD22, 2, 128);		// Set turn register to value in x	

}

unsigned char steps [8] = { 0x08, 0x09, 0x01, 0x03,0x02,0x06,0x04,0x0C};
unsigned char stepsPrime [8] = { 0x0C, 0x04, 0x06, 0x02,0x03,0x01,0x09,0x08};

int a = 0, b=0;
void turn(void){
	LATD = steps[a];    /* send step data to Port D move forward */
	Delay10KTCYx(5);   /* Short Delay */
	a++;               /* Point to the next step */
	if(a == 8)  a = 0; /* If last step point to first step */
}
void turnPrime(void){
	LATD = stepsPrime[b];    /* send step data to Port D move forward */
	Delay10KTCYx(5);   /* Short Delay */
	b++;               /* Point to the next step */
	if(b == 8)  b = 0; /* If last step point to first step */
}
void main(void)
{

	setup();
	//turnPrime();
	SetTimer(35000);								// Wait for everything to power up
	Wait4Timer();
	setup_md22();
	
	i2c_rx(MD22, 7, 1); 							// Get the software version of the MD22 put it in buffer[0]
	initComm();

  while(1){

	Stop();
  // wait for user input
  while (!DataRdyUSART());  //Make sure ready
	
      command=getcUSART();  //get character from buffer into C
	while(BusyUSART());  // wait till not busy 

 if (command == 'F'){// if command is 'F' go forward


    Forward();
	putrsUSART("\rMove forward\r");   // send the response message to user of character entered
 	
}
else if (command == 'B'){// if command is 'B' reverse
	Reverse();
	putrsUSART("\rMove backward\r");   // send the response message to user of character entered

}
else if (command == 'L'){// if command is 'L' move to the left
    Left();
	putrsUSART("\rMove left\r");   // send the response message to user of character entered

}
else if (command == 'R') {// if command is 'R' move to the right
	Right();
	putrsUSART("\rMove right\r");   // send the response message to user of character entered
}

else if (command == 'S'){// if command is 'S' change motor speed to 75
		speed = 75;
}

else if (command == 'N'){// if command is 'N' change motor speed to 50

		speed = 50;
}

else if (command == 'Q'){// if command is 'Q' change motor speed to 25

		speed = 25;
}
else if (command == 'r'){// if command is 'r' rotate stepper 7.5 degrees right
for	(count=0; count<1; count++){
		turn();
}
}
else if (command == 'l'){// if command is 'l' rotate stepper 7.5 degrees left
for	(count=0; count<15; count++){
		turnPrime();
}
}
  else{ 
		putrsUSART("\rI don't know this command\r\r");         // sent returns and new line and repeat process
  }
 }
		CloseUSART (); // close the USART if already opened*/
   }

void initComm(void){
unsigned int spbrg = 12; // intiliase spbrg used in setting baud rate to 9600
	
	TRISCbits.RC6 = 0; // Clear TRISC pins 6 and 7 (Set PORTC as OUTPUT)
	TRISCbits.RC7 = 0;
	
	PORTCbits.RC6 = 0; // Clear PORTC pins 6 and 7 (Clear the Input Data in PORTC)
	PORTCbits.RC7 = 0;

	while (!OSCCONbits.IOFS); // wait for OSC to be stable
		CloseUSART (); // close the USART if already opened
     /* Open Usart with transmit and recieve interrupt off, Asynchrous mode, 8 bit operation, 
	continuos reception, and set baud rate to 9600 = (FOSC / 64 * (spbrg + 1))  */
	
    OpenUSART ( USART_TX_INT_OFF & USART_RX_INT_OFF & USART_ASYNCH_MODE & USART_EIGHT_BIT & USART_CONT_RX & USART_BRGH_LOW, spbrg);
	
    putrsUSART( "\r\r*** This AMR communicating *** \r\r\n\n " );  //Sent the string to terminal
    Delay10KTCYx(50);   // Delay for a while
	while(BusyUSART());  // wait till not busy
	// write to the USART the welcoming prompt message                
    putrsUSART(" Give a direction to output  :  ");  // send this prompt

}


/****************
* MD22 routines *
****************/
void setup_md22(void)
{
	i2c_tx(MD22, 0, 2);			// Set the MD22 to mode 2, speed 1 controlls both motors
}

/*****************
* Timer Routines *
*****************/
void SetTimer(unsigned int time)
{
	TMR0H = 0-(time/256);
	TMR0L = 0-(time&0xff);
	INTCONbits.TMR0IF = 0;
}

void Wait4Timer(void)
{
	while(INTCONbits.TMR0IF==0);
}

/*************
* Chip setup *
*************/
void setup(void)
{	
	T0CON = 0x83;				// 16bit, 64:1 prescaler
	ADCON1 = 0x0f;				// all ports to digital
	LATD = 0x00; // Clear LATD (Clear the Ouput Data in PORTC)
	TRISD = 0x00; //  Make port D output
	OSCCON = 0x70;				// set 8MHz
	TRISC = 0x1F;
	SSPSTAT = 0x80;				// slew diabled
	SSPCON1 = 0x38;				// master mode enabled
	SSPADD = 0x11;				// 100khz
}

/********************************
* General comunication routines *
********************************/

void i2c_tx(unsigned char address, unsigned char reg, unsigned char data)
{
	SSPCON2bits.SEN = 1;		// innitiate a start bit
	while(SSPCON2bits.SEN);		// Wait for start bit to end
	PIR1bits.SSPIF = 0;			// Clear the i2c interupt flag
	SSPBUF = address;			// i2c address
	while(!PIR1bits.SSPIF);		// Wait for interupt flag to be set indicating and of a transmission
	PIR1bits.SSPIF = 0;		
	SSPBUF = reg;				// register to send i2c data to
	while(!PIR1bits.SSPIF);		
	PIR1bits.SSPIF = 0;		
	SSPBUF = data;				// data to be sent
	while(!PIR1bits.SSPIF);	
	SSPCON2bits.PEN = 1;		// Send stop bit
	while(SSPCON2bits.PEN);		// Wait for stop bit to finish
}

void i2c_rx(unsigned char address, unsigned char regRead, unsigned char byteCount)
{
	
	unsigned char x;
unsigned char buffer[10];		// Used to read data from i2c bus
	SSPCON2bits.SEN = 1;		// innitiate a start bit
	while(SSPCON2bits.SEN);		// Wait for start bit to end

	PIR1bits.SSPIF = 0;			
	SSPBUF = address;			// i2c address
	while(!PIR1bits.SSPIF);		// Wait for interupt flag showing byte is sent

	PIR1bits.SSPIF = 0;			
	SSPBUF = regRead;			// register to start reding from
	while(!PIR1bits.SSPIF);	
	
	SSPCON2bits.RSEN = 1;		// innitiate a restart bit
	while(SSPCON2bits.RSEN);	// Wait for restart bit to end

	PIR1bits.SSPIF = 0;			
	SSPBUF = (address|0x01);		// i2c address with read bit high
	while(!PIR1bits.SSPIF);	

	for(x = 0; x < (byteCount-1); x++)	// Recieve data into buffer
	{
		PIR1bits.SSPIF = 0;	
		SSPCON2bits.RCEN = 1;			// start recieve
		while(!PIR1bits.SSPIF);			// wait for recieve to finish
		buffer[x] = SSPBUF;
		SSPCON2bits.ACKDT = 0;			// Send an ack bit
		SSPCON2bits.ACKEN = 1;			
		while(SSPCON2bits.ACKEN);		// Wait for ack to finish		
	}

	PIR1bits.SSPIF = 0;	
	SSPCON2bits.RCEN = 1;			// start recieve
	while(!PIR1bits.SSPIF);			// wait for recieve to finish
	buffer[byteCount-1] = SSPBUF;
	SSPCON2bits.ACKDT = 1;			// Send an nack bit	
	SSPCON2bits.ACKEN = 1;			
	while(SSPCON2bits.ACKEN);		// Wait for ack to finish

	SSPCON2bits.PEN = 1;		// Send stop bit
	while(SSPCON2bits.PEN);		// Wait for stop bit to finish
}	